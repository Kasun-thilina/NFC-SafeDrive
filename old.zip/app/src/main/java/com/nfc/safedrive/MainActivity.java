package com.nfc.safedrive;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener
{
    public static final String TAG = MainActivity.class.getSimpleName();
    private NfcAdapter mNfcAdapter;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initNFC();
        reqPhonePermission();
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        navigation.setSelectedItemId(R.id.navigation_home);
        loadFragments(new HomeFragment());

    }


    /**
     *Bottom Navigation Bar
     */
    private boolean loadFragments(Fragment fragment)
    {
        if (fragment!=null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer,fragment).commitAllowingStateLoss();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment=null;

        switch(menuItem.getItemId()){
            case R.id.navigation_home:
                fragment=new HomeFragment();
                break;
            case R.id.navigation_settings:
                fragment=new SettingsFragment();
                break;
        }
        return loadFragments(fragment);
    }

    /**
     * End
     */

    /**
     * NFC Reader Initialization
     */
    private void initNFC(){
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
    }
    /**
     * Detecting NFC tag and returning to the home screen at any time
     */
    @Override
    protected void onNewIntent(Intent intent) {
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        Log.d(TAG, "onNewIntent: "+intent.getAction());
        BottomNavigationView navigation = findViewById(R.id.navigation);
        if(tag != null) {
            Toast.makeText(this, getString(R.string.message_tag_detected), Toast.LENGTH_SHORT).show();
            final Ndef ndef = Ndef.get(tag);
            onNfcDetected(ndef);
            loadFragments(new HomeFragment());
            navigation.setSelectedItemId(R.id.navigation_home);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        IntentFilter ndefDetected = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        IntentFilter techDetected = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
        IntentFilter[] nfcIntentFilter = new IntentFilter[]{techDetected,tagDetected,ndefDetected};

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        if(mNfcAdapter!= null)
            mNfcAdapter.enableForegroundDispatch(this, pendingIntent, nfcIntentFilter, null);
    }
    public void onNfcDetected(Ndef ndef){
        readFromNFC(ndef);
    }

    private void readFromNFC(Ndef ndef) {
    /**
     * This code is first verifying Weather the Attached NFC tag is the correct one.Then It keeps reading the tag
     * in a loop untill the tag detachs from the device.
     * Then After catching the detatch using IOException the other apps functionality can happen
     */
                try
                {
                        ndef.connect();
                        NdefMessage ndefMessage = ndef.getNdefMessage();
                        ndef.close();
                        String message = new String(ndefMessage.getRecords()[0].getPayload());
                        Log.d(TAG, "readFromNFC: " + message);
                        Toast.makeText(this, "Text" + message, Toast.LENGTH_LONG).show();
                        if (message.equals("in")) {
                            Toast.makeText(this.getApplicationContext(), R.string.message_nfc_holder_detected, Toast.LENGTH_LONG).show();
                            while (1==1)
                            {
                                ndef.connect();
                                ndefMessage = ndef.getNdefMessage();
                                 message = new String(ndefMessage.getRecords()[0].getPayload());
                                Log.d(TAG, "readFromNFC: " + message);
                                TimeUnit.SECONDS.sleep(1);
                                ndef.close();
                            }
                        } else {
                            Toast.makeText(this.getApplicationContext(), R.string.message_nfc_holder_error, Toast.LENGTH_LONG).show();
                            ndef.close();
                        }

                } catch (IOException | FormatException | InterruptedException e ) {
                    e.printStackTrace();
                    Toast.makeText(this.getApplicationContext(), R.string.message_nfc_holder_detached, Toast.LENGTH_LONG).show();
                    activateEmergency();
                }

            }

    /**
     * Dialing the phone number process
     */
    private void activateEmergency()
    {
        Intent dialer=new Intent(Intent.ACTION_CALL);
        dialer.setData(Uri.parse("tel:94769456670"));
        startActivity(dialer);
    }
    private void reqPhonePermission()
    {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},1);
        }
        else
        {
            return;
        }
    }

}
