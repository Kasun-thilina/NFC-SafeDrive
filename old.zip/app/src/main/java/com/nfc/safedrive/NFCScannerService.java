package com.nfc.safedrive;

import android.app.Service;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.IBinder;
import android.widget.Toast;

import org.jetbrains.annotations.Nullable;

public class NFCScannerService extends Service {
    public static final String TAG = MainActivity.class.getSimpleName();
    private NfcAdapter mNfcAdapter;

    @Override
    public void onCreate() {
        Toast.makeText(this, "NFC Scanning Service Started", Toast.LENGTH_LONG).show();
    }
    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service stopped", Toast.LENGTH_LONG).show();
    }
    @Override
    public void onStart(Intent intent, int startId) {
        //do something
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
