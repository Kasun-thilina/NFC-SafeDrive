package com.nfc.safedrive;

public interface Listener {

    void onDialogDisplayed();

    void onDialogDismissed();
}
